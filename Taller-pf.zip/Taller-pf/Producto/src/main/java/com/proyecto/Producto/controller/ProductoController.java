package com.proyecto.Producto.controller;
import com.proyecto.Producto.model.Producto;
import com.proyecto.Producto.service.ProductoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/productos")
public class ProductoController {

    @Autowired
    private ProductoService productoService;

    @GetMapping
    public List<Producto> listarProductos() {
        return productoService.obtenerProductos();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Producto> obtenerProducto(@PathVariable int id) {
        return productoService.obtenerPorId(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Producto crearProducto(@RequestBody Producto producto) {
        return productoService.agregarProducto(producto);
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarProducto(@PathVariable int id, @RequestBody Producto producto) {
        producto.setId(id);
        if (productoService.actualizarProducto(producto)) {
            return ResponseEntity.ok("Producto actualizado correctamente.");
        }
        return ResponseEntity.status(404).body("Producto no encontrado.");
    }

    @PatchMapping("/{id}")
    public ResponseEntity<?> actualizarParcialProducto(@PathVariable int id, @RequestBody Producto datos) {
        if (productoService.actualizarParcial(id, datos)) {
            return ResponseEntity.ok("Producto actualizado parcialmente.");
        }
        return ResponseEntity.status(404).body("Producto no encontrado.");
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarProducto(@PathVariable int id) {
        if (productoService.eliminarProducto(id)) {
            return ResponseEntity.ok("Producto eliminado.");
        }
        return ResponseEntity.status(404).body("Producto no encontrado.");
    }
}
