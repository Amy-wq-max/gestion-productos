package com.proyecto.Producto.repository;

import com.proyecto.Producto.model.Producto;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Repository
public class ProductoRepository {
    private List<Producto> productos = new ArrayList<>();
    private int contadorId = 1;

    public List<Producto> obtenerTodos() {
        return productos;
    }

    public Producto guardar(Producto producto) {
        producto.setId(contadorId++);
        productos.add(producto);
        return producto;
    }

    public Optional<Producto> buscarPorId(int id) {
        return productos.stream()
                .filter(p -> p.getId() == id)
                .findFirst();
    }

    public boolean actualizar(Producto producto) {
        for (int i = 0; i < productos.size(); i++) {
            if (productos.get(i).getId() == producto.getId()) {
                productos.set(i, producto);
                return true;
            }
        }
        return false;
    }

    public boolean actualizarParcial(int id, Producto datos) {
        for (Producto p : productos) {
            if (p.getId() == id) {
                if (datos.getNombre() != null) p.setNombre(datos.getNombre());
                if (datos.getCategoria() != null) p.setCategoria(datos.getCategoria());
                if (datos.getPrecio() != 0) p.setPrecio(datos.getPrecio());
                return true;
            }
        }
        return false;
    }

    public boolean eliminar(int id) {
        return productos.removeIf(p -> p.getId() == id);
    }
}

