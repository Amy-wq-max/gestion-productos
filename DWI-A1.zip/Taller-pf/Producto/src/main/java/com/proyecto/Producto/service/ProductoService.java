package com.proyecto.Producto.service;
import java.util.*;
import com.proyecto.Producto.model.Producto;
import com.proyecto.Producto.repository.ProductoRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

@Service
public class ProductoService {

    @Autowired
    private ProductoRepository productoRepository;

    public List<Producto> obtenerProductos() {
        return productoRepository.obtenerTodos();
    }

    public Producto agregarProducto(Producto producto) {
        return productoRepository.guardar(producto);
    }

    public Optional<Producto> obtenerPorId(int id) {
        return productoRepository.buscarPorId(id);
    }

    public boolean actualizarProducto(Producto producto) {
        return productoRepository.actualizar(producto);
    }

    public boolean actualizarParcial(int id, Producto datos) {
        return productoRepository.actualizarParcial(id, datos);
    }

    public boolean eliminarProducto(int id) {
        return productoRepository.eliminar(id);
    }
}
